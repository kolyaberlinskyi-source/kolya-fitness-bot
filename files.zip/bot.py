import os
import asyncio
import logging
from datetime import datetime, date, timedelta
from telegram import Update
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes
import anthropic
import httpx

# ============ ТОКЕНЫ ============
TELEGRAM_TOKEN = "8602988968:AAHv7zlhjbQ9mm9VnU1HJ6MLoaYtGDc8AAk"
OURA_TOKEN = "YNGJNUDLFWRX2YA7JVDVQV4O7K3OFMDT"
ANTHROPIC_API_KEY = "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"

# ============ НАСТРОЙКИ ============
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

client = anthropic.Anthropic(api_key=ANTHROPIC_API_KEY)

SYSTEM_PROMPT = """Ты персональный фитнес-коуч и нутрициолог по имени Коля-бот. 
Твоя главная цель — помочь пользователю похудеть через умный анализ его данных здоровья.

Пользователь занимается: футбол, падел, зал (gym).
Данные приходят из Oura Ring.

Твой стиль:
- Говори по-русски, дружелюбно и мотивирующе
- Объясняй ПОЧЕМУ, не просто показывай цифры
- Связывай данные между собой (стресс → кортизол → вес, сон → аппетит и т.д.)
- Давай конкретные советы на завтра/сегодня
- Используй эмодзи умеренно
- Будь честным — если что-то не так, говори прямо но с поддержкой

Когда анализируешь данные, всегда объясняй:
1. Что происходит с телом
2. Почему это влияет на похудение
3. Что конкретно сделать

Данные за сегодня/период будут переданы тебе в сообщении."""

# История разговора (в памяти, сбрасывается при рестарте)
conversation_history = []

# ============ OURA API ============
async def get_oura_data(days_back: int = 1) -> dict:
    """Получить данные из Oura за последние N дней"""
    end_date = date.today()
    start_date = end_date - timedelta(days=days_back)
    
    headers = {"Authorization": f"Bearer {OURA_TOKEN}"}
    base_url = "https://api.ouraring.com/v2/usercollection"
    
    params = {
        "start_date": start_date.isoformat(),
        "end_date": end_date.isoformat()
    }
    
    data = {}
    
    async with httpx.AsyncClient() as http_client:
        # Сон
        try:
            r = await http_client.get(f"{base_url}/sleep", headers=headers, params=params)
            data["sleep"] = r.json().get("data", [])
        except Exception as e:
            data["sleep"] = []
            logger.error(f"Sleep error: {e}")
        
        # Активность
        try:
            r = await http_client.get(f"{base_url}/daily_activity", headers=headers, params=params)
            data["activity"] = r.json().get("data", [])
        except Exception as e:
            data["activity"] = []
            logger.error(f"Activity error: {e}")
        
        # Готовность (readiness)
        try:
            r = await http_client.get(f"{base_url}/daily_readiness", headers=headers, params=params)
            data["readiness"] = r.json().get("data", [])
        except Exception as e:
            data["readiness"] = []
            logger.error(f"Readiness error: {e}")
        
        # Стресс
        try:
            r = await http_client.get(f"{base_url}/daily_stress", headers=headers, params=params)
            data["stress"] = r.json().get("data", [])
        except Exception as e:
            data["stress"] = []
            logger.error(f"Stress error: {e}")

        # Тренировки
        try:
            r = await http_client.get(f"{base_url}/workout", headers=headers, params=params)
            data["workouts"] = r.json().get("data", [])
        except Exception as e:
            data["workouts"] = []
            logger.error(f"Workout error: {e}")

        # Сердечный ритм
        try:
            r = await http_client.get(f"{base_url}/daily_cardiovascular_age", headers=headers, params=params)
            data["cardio"] = r.json().get("data", [])
        except Exception as e:
            data["cardio"] = []

    return data

def format_oura_data(data: dict) -> str:
    """Форматировать данные Oura в текст для Claude"""
    lines = [f"📊 ДАННЫЕ OURA (за последние дни, сегодня {date.today().isoformat()})\n"]
    
    # Сон
    if data.get("sleep"):
        lines.append("😴 СОН:")
        for s in data["sleep"][-3:]:  # последние 3 дня
            day = s.get("day", "?")
            duration = round(s.get("total_sleep_duration", 0) / 3600, 1)
            efficiency = s.get("efficiency", "?")
            deep = round(s.get("deep_sleep_duration", 0) / 3600, 1)
            rem = round(s.get("rem_sleep_duration", 0) / 3600, 1)
            score = s.get("score", "?")
            hrv = s.get("average_hrv", "?")
            hr = s.get("average_heart_rate", "?")
            lines.append(f"  {day}: {duration}ч сна, скор={score}, эффективность={efficiency}%, глубокий={deep}ч, REM={rem}ч, HRV={hrv}, ЧСС={hr}")
    
    # Активность
    if data.get("activity"):
        lines.append("\n🏃 АКТИВНОСТЬ:")
        for a in data["activity"][-3:]:
            day = a.get("day", "?")
            steps = a.get("steps", "?")
            calories = a.get("total_calories", "?")
            active_cal = a.get("active_calories", "?")
            score = a.get("score", "?")
            met = a.get("met", {})
            lines.append(f"  {day}: шаги={steps}, калории={calories} (актив={active_cal}), скор={score}")
    
    # Готовность
    if data.get("readiness"):
        lines.append("\n🔋 ВОССТАНОВЛЕНИЕ:")
        for r in data["readiness"][-3:]:
            day = r.get("day", "?")
            score = r.get("score", "?")
            hrv_bal = r.get("contributors", {}).get("hrv_balance", "?")
            recovery = r.get("contributors", {}).get("recovery_index", "?")
            lines.append(f"  {day}: скор={score}, HRV баланс={hrv_bal}, индекс восст.={recovery}")
    
    # Стресс
    if data.get("stress"):
        lines.append("\n😓 СТРЕСС:")
        for s in data["stress"][-3:]:
            day = s.get("day", "?")
            stress_high = s.get("stress_high", "?")
            recovery_high = s.get("recovery_high", "?")
            summary = s.get("day_summary", "?")
            lines.append(f"  {day}: стресс={stress_high}мин, восст={recovery_high}мин, итог={summary}")
    
    # Тренировки
    if data.get("workouts"):
        lines.append("\n💪 ТРЕНИРОВКИ:")
        for w in data["workouts"][-5:]:
            day = w.get("day", "?")
            activity = w.get("activity", "?")
            duration = round(w.get("duration", 0) / 60)
            calories = w.get("calories", "?")
            lines.append(f"  {day}: {activity}, {duration}мин, {calories}ккал")
    
    if len(lines) == 1:
        return "Данные из Oura не получены или пусты."
    
    return "\n".join(lines)

# ============ CLAUDE АГЕНТ ============
async def ask_claude(user_message: str, oura_data_str: str = "") -> str:
    """Спросить Claude с контекстом данных"""
    global conversation_history
    
    # Добавляем данные Oura к сообщению если есть
    full_message = user_message
    if oura_data_str:
        full_message = f"{oura_data_str}\n\nВопрос пользователя: {user_message}"
    
    conversation_history.append({
        "role": "user",
        "content": full_message
    })
    
    # Держим историю не больше 20 сообщений
    if len(conversation_history) > 20:
        conversation_history = conversation_history[-20:]
    
    response = client.messages.create(
        model="claude-opus-4-5",
        max_tokens=1000,
        system=SYSTEM_PROMPT,
        messages=conversation_history
    )
    
    assistant_message = response.content[0].text
    conversation_history.append({
        "role": "assistant", 
        "content": assistant_message
    })
    
    return assistant_message

# ============ TELEGRAM HANDLERS ============
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "Привет! 👋 Я твой персональный фитнес-коуч.\n\n"
        "Я анализирую твои данные из Oura Ring и помогаю тебе худеть умно.\n\n"
        "Команды:\n"
        "/today — анализ сегодняшнего дня\n"
        "/week — анализ за неделю\n"
        "/tip — совет на сегодня\n\n"
        "Или просто пиши мне что угодно! 💪"
    )

async def today_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("⏳ Загружаю твои данные из Oura...")
    
    data = await get_oura_data(days_back=2)
    data_str = format_oura_data(data)
    
    response = await ask_claude(
        "Сделай полный анализ моего дня. Как я себя чувствую? Что происходит с моим телом? Как это влияет на похудение? Дай конкретные советы на завтра.",
        data_str
    )
    
    await update.message.reply_text(response)

async def week_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("⏳ Загружаю данные за неделю...")
    
    data = await get_oura_data(days_back=7)
    data_str = format_oura_data(data)
    
    response = await ask_claude(
        "Сделай анализ за неделю. Какие тренды? Почему я худею или не худею? Что нужно изменить?",
        data_str
    )
    
    await update.message.reply_text(response)

async def tip_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    data = await get_oura_data(days_back=1)
    data_str = format_oura_data(data)
    
    response = await ask_claude(
        "Дай мне один конкретный совет на сегодня исходя из моих данных. Коротко и по делу.",
        data_str
    )
    
    await update.message.reply_text(response)

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_text = update.message.text
    
    # Если вопрос про данные — грузим Oura
    keywords = ["сегодня", "вчера", "неделя", "данные", "как я", "сон", "стресс", 
                "шаги", "калории", "вес", "тренировка", "восстановление", "устал",
                "худею", "прогресс", "результат"]
    
    need_data = any(kw in user_text.lower() for kw in keywords)
    
    oura_str = ""
    if need_data:
        await update.message.reply_text("⏳ Смотрю твои данные...")
        data = await get_oura_data(days_back=3)
        oura_str = format_oura_data(data)
    
    response = await ask_claude(user_text, oura_str)
    await update.message.reply_text(response)

# ============ ЗАПУСК ============
def main():
    app = Application.builder().token(TELEGRAM_TOKEN).build()
    
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("today", today_command))
    app.add_handler(CommandHandler("week", week_command))
    app.add_handler(CommandHandler("tip", tip_command))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    
    logger.info("🤖 Бот запущен!")
    app.run_polling()

if __name__ == "__main__":
    main()
